import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";

// `base: "./"` makes all asset paths RELATIVE so the built site works under any
// GitHub Pages subpath, e.g. https://username.github.io/wazzan-wash-demo/
// without needing to know the repo name at build time.
export default defineConfig({
  base: "./",
  plugins: [react()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  build: {
    outDir: "dist",
    assetsDir: "assets",
  },
});