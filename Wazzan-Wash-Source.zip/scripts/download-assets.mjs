// Downloads the 5 automotive images from the original public CDN into
// public/assets/ so the static build has zero runtime dependency on Base44.
// Runs automatically on `predev` and `prebuild`. Safe to re-run; skips files
// that already exist unless --force is passed. Requires Node 18+ (global fetch).
import { mkdir, writeFile, access } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const assetsDir = join(__dirname, "..", "public", "assets");
const force = process.argv.includes("--force");

const IMAGES = [
  { name: "hero.jpg", url: "https://media.base44.com/images/public/6aad99868a793b2c2fadede3/8ff646fd1_generated_e0f28c28.jpg" },
  { name: "gallery-wide.jpg", url: "https://media.base44.com/images/public/6aad99868a793b2c2fadede3/56049aafb_generated_9299c65d.jpg" },
  { name: "gallery-dashboard.jpg", url: "https://media.base44.com/images/public/6aad99868a793b2c2fadede3/d428ce22b_generated_2f06c763.jpg" },
  { name: "gallery-foam.jpg", url: "https://media.base44.com/images/public/6aad99868a793b2c2fadede3/ee3817ea0_generated_cfe0b1c4.jpg" },
  { name: "gallery-wheel.jpg", url: "https://media.base44.com/images/public/6aad99868a793b2c2fadede3/0500e8344_generated_ee8585fe.jpg" },
];

async function exists(p) {
  try { await access(p); return true; } catch { return false; }
}

await mkdir(assetsDir, { recursive: true });

let ok = 0;
for (const img of IMAGES) {
  const dest = join(assetsDir, img.name);
  if (!force && await exists(dest)) {
    console.log(`• ${img.name} (already present, skip)`);
    ok++;
    continue;
  }
  try {
    const res = await fetch(img.url, { redirect: "follow" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    await writeFile(dest, buf);
    console.log(`✓ ${img.name} (${(buf.length / 1024).toFixed(0)} KB)`);
    ok++;
  } catch (e) {
    console.warn(`⚠ Failed to download ${img.name}: ${e.message}`);
    console.warn(`  The build will still succeed, but this image will be missing.`);
    console.warn(`  Re-run: node scripts/download-assets.mjs --force`);
  }
}

console.log(`\nAssets download complete (${ok}/${IMAGES.length}). Directory: public/assets/`);