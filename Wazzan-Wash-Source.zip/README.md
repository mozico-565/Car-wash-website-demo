# Wazzan Wash — Static GitHub Pages Export

This is a **fully standalone** copy of the Wazzan Wash marketing website. It has **zero dependency on Base44** — no SDK, no APIs, no auth, no database, no backend, no environment variables. Booking is handled entirely client-side via WhatsApp (`https://wa.me/966533311370`).

The design, copy, colors, fonts, spacing, animations, and responsive behavior are **identical** to the original site.

---

## Tech stack

- React 18 + Vite 5 (ESM)
- Tailwind CSS 3 (design tokens via CSS variables in `src/index.css`)
- framer-motion (scroll reveals + bottom sheet)
- lucide-react (icons)
- Google Fonts: **IBM Plex Sans Arabic** + **IBM Plex Mono** (loaded from `index.html`)
- No React Router (single page, native anchor navigation — works on GitHub Pages with no server rewrites)

---

## Run locally

```bash
npm install
npm run dev
```

Open the printed URL (default http://localhost:5173).

> The first `dev`/`build` automatically downloads the 5 site images into `public/assets/` via `scripts/download-assets.mjs` (requires internet). They are then cached locally; re-runs skip them. To force re-download: `node scripts/download-assets.mjs --force`.

## Build for production

```bash
npm run build      # outputs to ./dist
npm run preview    # preview the built site locally
```

`vite.config.js` uses `base: "./"` so **all asset paths are relative** — the built site works under any GitHub Pages subpath (e.g. `https://username.github.io/wazzan-wash-demo/`) with no extra configuration.

---

## Deploy to GitHub Pages (automatic)

1. Create a new GitHub repository, e.g. `wazzan-wash-demo`.
2. Push the **contents** of this `github-pages-export/` folder to the repo root (or push the whole folder and adjust the workflow `path` accordingly). Recommended: push the folder's contents to the root of the repo so the Pages URL is clean.
3. In the repo: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Push to `main`. The workflow at `.github/workflows/pages.yml` builds the site and publishes it to GitHub Pages automatically.

The site will be live at `https://<username>.github.io/<repo>/`.

> No refresh 404s: navigation uses in-page hash anchors (`#services`, `#booking`, …). The hash is never sent to the server, so refreshing any URL just loads `index.html` and scrolls — no special routing or 404 fallback needed.

---

## Project structure

```
github-pages-export/
├─ .github/workflows/pages.yml   # CI: build + deploy to Pages
├─ public/assets/                # downloaded images (auto)
├─ scripts/download-assets.mjs   # fetches images into public/assets
├─ src/
│  ├─ App.jsx
│  ├─ main.jsx
│  ├─ index.css                  # design tokens (colors, fonts, radius)
│  ├─ lib/wazzan.js              # WhatsApp config + image paths + helpers
│  ├─ hooks/useMediaQuery.js
│  ├─ components/ui/image.jsx    # local Image (no Base44/Wix media)
│  └─ components/wazzan/          # all sections
│  └─ pages/Home.jsx
├─ index.html
├─ vite.config.js                # base: "./", @ alias
├─ tailwind.config.js
├─ postcss.config.js
├─ package.json
└─ *.txt                         # manifests (see below)
```

---

## Manifest files

- `FILES_MANIFEST.txt` — every file to transfer to GitHub
- `DEPENDENCIES.txt` — npm packages + versions
- `ASSETS_MANIFEST.txt` — images: original URL → local path → usage
- `DESIGN_TOKENS.txt` — full design system reference
- `COMPONENT_MAP.txt` — sections → components → files → dependencies
- `EXPORT_INSTRUCTIONS.txt` — quick transfer + deploy steps

---

## Notes

- WhatsApp number is hardcoded in `src/lib/wazzan.js` (`WHATSAPP_NUMBER = "966533311370"`). Change it there if needed.
- No data is ever stored. The booking form opens WhatsApp with a pre-filled Arabic message.