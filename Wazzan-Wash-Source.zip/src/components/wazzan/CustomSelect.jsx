import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Check } from "lucide-react";
import { useMediaQuery } from "@/hooks/useMediaQuery";
import BottomSheet from "./BottomSheet";

// Custom select field — NO native HTML select.
// Mobile: bottom sheet. Desktop: anchored popover dropdown.
export default function CustomSelect({
  label,
  placeholder,
  value,
  options,
  onChange,
  error = false,
  sheetTitle,
}) {
  const isDesktop = useMediaQuery("(min-width: 768px)");
  const [sheetOpen, setSheetOpen] = useState(false);
  const [popOpen, setPopOpen] = useState(false);
  const wrapRef = useRef(null);

  // Close desktop popover on outside click / escape.
  useEffect(() => {
    if (!popOpen) return;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setPopOpen(false);
    };
    const onKey = (e) => e.key === "Escape" && setPopOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [popOpen]);

  const open = () => {
    if (isDesktop) setPopOpen((v) => !v);
    else setSheetOpen(true);
  };

  const borderColor = error
    ? "border-[#F7F6F2]/40"
    : "border-[#A6A6A1]/15 focus-within:border-[#F7F6F2]/50";

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-[13px] tracking-wide text-[#A6A6A1] font-medium">
          {label}
        </label>
      )}
      <div className="relative" ref={wrapRef}>
        <button
          type="button"
          onClick={open}
          aria-haspopup="listbox"
          aria-expanded={sheetOpen || popOpen}
          className={`w-full min-h-[56px] bg-[#050505] px-5 rounded-[12px] flex items-center justify-between gap-3 border transition-colors ${borderColor}`}
        >
          <span className={`text-[16px] ${value ? "text-[#F7F6F2]" : "text-[#A6A6A1]"}`}>
            {value || placeholder}
          </span>
          <ChevronDown
            size={20}
            strokeWidth={1.75}
            className={`text-[#A6A6A1] shrink-0 transition-transform ${popOpen ? "rotate-180" : ""}`}
          />
        </button>

        {/* Desktop popover */}
        <AnimatePresence>
          {popOpen && isDesktop && (
            <motion.ul
              role="listbox"
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16, ease: "easeOut" }}
              className="absolute z-50 top-[calc(100%+8px)] inset-x-0 bg-[#111111] border border-[#A6A6A1]/20 rounded-[12px] py-1.5 shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
            >
              {options.map((opt) => {
                const active = value === opt;
                return (
                  <li key={opt}>
                    <button
                      type="button"
                      onClick={() => {
                        onChange(opt);
                        setPopOpen(false);
                      }}
                      className={`w-full min-h-[48px] px-5 flex items-center justify-between text-[15px] transition-colors ${
                        active ? "text-[#F7F6F2]" : "text-[#A6A6A1] hover:text-[#F7F6F2] hover:bg-white/[0.04]"
                      }`}
                    >
                      <span>{opt}</span>
                      {active && <Check size={18} strokeWidth={2} />}
                    </button>
                  </li>
                );
              })}
            </motion.ul>
          )}
        </AnimatePresence>
      </div>

      {/* Mobile bottom sheet */}
      <BottomSheet
        isOpen={sheetOpen && !isDesktop}
        onClose={() => setSheetOpen(false)}
        title={sheetTitle || label || placeholder}
        options={options}
        selectedValue={value}
        onSelect={onChange}
      />
    </div>
  );
}