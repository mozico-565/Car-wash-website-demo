import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";

const NAV = [
  { href: "#services", label: "الخدمات" },
  { href: "#how", label: "كيف نعمل" },
  { href: "#gallery", label: "الأعمال" },
  { href: "#booking", label: "الحجز" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const goBooking = (e) => {
    e?.preventDefault?.();
    setOpen(false);
    document.getElementById("booking")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 inset-x-0 z-[80] transition-colors duration-300 ${
        scrolled ? "bg-[#050505]/85 backdrop-blur-md border-b border-[#A6A6A1]/10" : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8">
        <div className="h-16 sm:h-20 flex items-center justify-between gap-4">
          {/* Wordmark — LTR, easy asset replacement point */}
          <a href="#top" className="flex items-center" aria-label="Red Wash">
            <span
              className="text-[17px] sm:text-[19px] font-bold tracking-[0.18em] text-[#F7F6F2]"
              style={{ direction: "ltr", fontFamily: "'IBM Plex Sans Arabic', sans-serif" }}
            >
              RED<span className="text-[#D62828]"> WASH</span>
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-9">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="text-[14px] font-medium text-[#A6A6A1] hover:text-[#F7F6F2] transition-colors"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={goBooking}
              className="hidden sm:inline-flex items-center justify-center bg-[#D62828] text-white px-5 py-2.5 rounded-[12px] text-[14px] font-semibold hover:bg-[#E23838] active:scale-[0.98] transition-all min-h-[40px]"
            >
              احجز الآن
            </button>

            {/* Mobile menu toggle */}
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-label="القائمة"
              aria-expanded={open}
              className="md:hidden w-11 h-11 flex items-center justify-center text-[#F7F6F2]"
            >
              {open ? <X size={22} strokeWidth={1.75} /> : <Menu size={22} strokeWidth={1.75} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile dropdown menu */}
      {open && (
        <div className="md:hidden bg-[#050505]/95 backdrop-blur-md border-b border-[#A6A6A1]/10">
          <nav className="px-5 py-4 flex flex-col">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="py-3.5 text-[16px] text-[#F7F6F2] border-b border-[#A6A6A1]/10 last:border-0"
              >
                {n.label}
              </a>
            ))}
            <button
              type="button"
              onClick={goBooking}
              className="mt-4 bg-[#D62828] text-white py-3.5 rounded-[12px] text-[15px] font-semibold"
            >
              احجز الآن
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}