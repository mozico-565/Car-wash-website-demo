import { motion } from "framer-motion";
import { Image } from "@/components/ui/image";
import Reveal from "./Reveal";
import { IMAGES } from "@/lib/redwash";

// Editorial gallery — varied sizes, tight gaps, no equal grid.
export default function Gallery() {
  return (
    <section id="gallery" className="py-20 sm:py-32 overflow-x-clip">
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8">
        <Reveal>
          <div className="border-b border-[#A6A6A1]/15 pb-8 mb-10">
            <p className="text-[12px] tracking-[0.3em] text-[#A6A6A1] font-mono-num uppercase mb-3">
              03 — Work
            </p>
            <h2 className="text-[30px] sm:text-[44px] font-bold tracking-tight">الأعمال</h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-2 md:grid-cols-12 gap-2 sm:gap-3">
          {/* Large wide image */}
          <Reveal className="col-span-2 md:col-span-8" y={20}>
            <motion.div
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="relative aspect-[16/10] md:aspect-[16/9] overflow-hidden rounded-[10px] bg-[#111111]"
            >
              <Image
                src={IMAGES.galleryWide}
                alt="سيارة فاخرة في بيئة جدة الحضرية عند الغسق"
                fittingType="fill"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </Reveal>

          {/* Tall foam */}
          <Reveal className="col-span-1 md:col-span-4" delay={0.1} y={20}>
            <motion.div
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="relative aspect-[3/4] overflow-hidden rounded-[10px] bg-[#111111]"
            >
              <Image
                src={IMAGES.galleryFoam}
                alt="رغوة الغسيل على سطح الطلاء"
                fittingType="fill"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </Reveal>

          {/* Dashboard detail */}
          <Reveal className="col-span-1 md:col-span-4" delay={0.15} y={20}>
            <motion.div
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="relative aspect-[3/4] overflow-hidden rounded-[10px] bg-[#111111]"
            >
              <Image
                src={IMAGES.galleryDashboard}
                alt="عناية بالمقصورة الداخلية"
                fittingType="fill"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </Reveal>

          {/* Wheel detail wide */}
          <Reveal className="col-span-2 md:col-span-8" delay={0.2} y={20}>
            <motion.div
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="relative aspect-[16/10] md:aspect-[16/9] overflow-hidden rounded-[10px] bg-[#111111]"
            >
              <Image
                src={IMAGES.galleryWheel}
                alt="تفاصيل الإطار والعجلة بعد الغسيل"
                fittingType="fill"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </Reveal>
        </div>

        <p className="mt-8 text-[12px] sm:text-[13px] text-[#A6A6A1]/70">
          صور توضيحية — يتم استبدالها لاحقاً بصور أعمال Red Wash الرسمية.
        </p>
      </div>
    </section>
  );
}