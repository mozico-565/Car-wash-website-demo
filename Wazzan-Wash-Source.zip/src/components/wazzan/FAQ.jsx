import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import Reveal from "./Reveal";

const FAQS = [
  {
    q: "كيف أحجز؟",
    a: "اختر الخدمة ونوع سيارتك والحي والموعد من نموذج الحجز، ثم اضغط إرسال الطلب عبر واتساب ونتواصل معك للتأكيد.",
  },
  {
    q: "كيف أتأكد من توفر الخدمة؟",
    a: "أرسل نوع سيارتك والخدمة المطلوبة وموقعك عبر واتساب، وسيتم تأكيد التوفر معك مباشرة.",
  },
  {
    q: "كيف أعرف السعر؟",
    a: "الخدمات والأسعار النهائية يتم تأكيدها عند الحجز بناءً على نوع سيارتك والخدمة المطلوبة.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="py-20 sm:py-28 bg-[#0a0a0a]">
      <div className="mx-auto max-w-[860px] px-5 sm:px-8">
        <Reveal>
          <div className="border-b border-[#A6A6A1]/15 pb-8 mb-8">
            <p className="text-[12px] tracking-[0.3em] text-[#A6A6A1] font-mono-num uppercase mb-3">
              05 — FAQ
            </p>
            <h2 className="text-[30px] sm:text-[44px] font-bold tracking-tight">الأسئلة الشائعة</h2>
          </div>
        </Reveal>

        <div className="divide-y divide-[#A6A6A1]/15">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={item.q} delay={i * 0.06}>
                <div>
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? -1 : i)}
                    aria-expanded={isOpen}
                    className="w-full flex items-center justify-between gap-4 py-6 text-right"
                  >
                    <span className="text-[17px] sm:text-[20px] font-medium text-[#F7F6F2]">
                      {item.q}
                    </span>
                    <span className="w-9 h-9 shrink-0 rounded-full border border-[#A6A6A1]/25 flex items-center justify-center text-[#A6A6A1]">
                      {isOpen ? <Minus size={16} strokeWidth={1.75} /> : <Plus size={16} strokeWidth={1.75} />}
                    </span>
                  </button>
                  <div
                    className="overflow-hidden transition-all duration-300"
                    style={{ maxHeight: isOpen ? 200 : 0 }}
                  >
                    <p className="pb-6 text-[15px] sm:text-[16px] text-[#A6A6A1] leading-[1.7] max-w-xl">
                      {item.a}
                    </p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}