import Reveal from "./Reveal";

const STEPS = [
  { id: "01", title: "اختر الخدمة", desc: "حدد نوع الخدمة المناسبة لسيارتك" },
  { id: "02", title: "أرسل موقعك", desc: "شارك معنا الحي والموقع في جدة" },
  { id: "03", title: "حدد الموعد", desc: "نتواصل معك لتأكيد الوقت والتوفر" },
];

export default function HowItWorks() {
  return (
    <section id="how" className="py-20 sm:py-28 bg-[#0a0a0a]">
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8">
        <Reveal>
          <div className="border-b border-[#A6A6A1]/15 pb-8 mb-12">
            <p className="text-[12px] tracking-[0.3em] text-[#A6A6A1] font-mono-num uppercase mb-3">
              02 — Process
            </p>
            <h2 className="text-[30px] sm:text-[44px] font-bold tracking-tight">كيف نعمل</h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-px bg-[#A6A6A1]/15">
          {STEPS.map((s, i) => (
            <Reveal key={s.id} delay={i * 0.1} className="bg-[#0a0a0a]">
              <div className="h-full p-7 sm:p-9 flex flex-col">
                <span className="font-mono-num text-[13px] text-[#A6A6A1] mb-6">{s.id}</span>
                <h3 className="text-[22px] sm:text-[26px] font-semibold tracking-tight mb-2.5">
                  {s.title}
                </h3>
                <p className="text-[14px] sm:text-[15px] text-[#A6A6A1] leading-relaxed">
                  {s.desc}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}