import { useState } from "react";
import { MessageCircle, AlertCircle } from "lucide-react";
import CustomSelect from "./CustomSelect";
import Reveal from "./Reveal";
import { SERVICE_OPTIONS, CAR_TYPES, buildBookingMessage, openWhatsApp } from "@/lib/redwash";

const EMPTY = { service: "", carType: "", district: "", time: "", notes: "" };

export default function Booking() {
  const [booking, setBooking] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState(false);

  const set = (key) => (val) => setBooking((b) => ({ ...b, [key]: val }));

  const validate = () => {
    const e = {};
    if (!booking.service) e.service = true;
    if (!booking.carType) e.carType = true;
    if (!booking.district.trim()) e.district = true;
    if (!booking.time.trim()) e.time = true;
    return e;
  };

  const submit = () => {
    const e = validate();
    setErrors(e);
    setTouched(true);
    if (Object.keys(e).length > 0) {
      const first = document.querySelector("[data-field-error='true']");
      first?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    openWhatsApp(buildBookingMessage(booking));
  };

  const inputBase =
    "w-full min-h-[56px] bg-[#050505] px-5 rounded-[12px] border text-[16px] text-[#F7F6F2] placeholder:text-[#A6A6A1] outline-none transition-colors";
  const inputColor = (err) =>
    err ? "border-[#F7F6F2]/40 focus:border-[#F7F6F2]" : "border-[#A6A6A1]/15 focus:border-[#F7F6F2]/50";

  return (
    <section id="booking" className="py-20 sm:py-32 bg-[#111111]">
      <div className="mx-auto max-w-[860px] px-5 sm:px-8">
        <Reveal>
          <div className="text-center mb-12 sm:mb-16">
            <p className="text-[12px] tracking-[0.3em] text-[#A6A6A1] font-mono-num uppercase mb-3">
              04 — Booking
            </p>
            <h2 className="text-[30px] sm:text-[44px] font-bold tracking-tight mb-4">
              احجز موعدك الآن
            </h2>
            <p className="text-[15px] sm:text-[17px] text-[#A6A6A1] max-w-md mx-auto leading-relaxed">
              حدد الخدمة وتفاصيل سيارتك، ثم أرسل الطلب مباشرة عبر واتساب للاستفسار أو تأكيد الموعد.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div data-field-error={touched && errors.service ? "true" : undefined}>
              <CustomSelect
                label="الخدمة"
                placeholder="اختر الخدمة"
                sheetTitle="اختر الخدمة"
                value={booking.service}
                options={SERVICE_OPTIONS}
                onChange={set("service")}
                error={touched && errors.service}
              />
            </div>
            <div data-field-error={touched && errors.carType ? "true" : undefined}>
              <CustomSelect
                label="نوع السيارة"
                placeholder="اختر النوع"
                sheetTitle="اختر نوع السيارة"
                value={booking.carType}
                options={CAR_TYPES}
                onChange={set("carType")}
                error={touched && errors.carType}
              />
            </div>

            <div data-field-error={touched && errors.district ? "true" : undefined}>
              <label className="block text-[13px] tracking-wide text-[#A6A6A1] font-medium mb-2">
                الحي في جدة
              </label>
              <input
                type="text"
                value={booking.district}
                onChange={(e) => set("district")(e.target.value)}
                placeholder="مثال: حي الروضة"
                className={`${inputBase} ${inputColor(touched && errors.district)}`}
              />
            </div>

            <div data-field-error={touched && errors.time ? "true" : undefined}>
              <label className="block text-[13px] tracking-wide text-[#A6A6A1] font-medium mb-2">
                الموعد المفضل
              </label>
              <input
                type="text"
                value={booking.time}
                onChange={(e) => set("time")(e.target.value)}
                placeholder="مثال: غداً الساعة ٤ عصراً"
                className={`${inputBase} ${inputColor(touched && errors.time)}`}
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-[13px] tracking-wide text-[#A6A6A1] font-medium mb-2">
                ملاحظات اختيارية
              </label>
              <textarea
                rows={3}
                value={booking.notes}
                onChange={(e) => set("notes")(e.target.value)}
                placeholder="أي تفاصيل إضافية تود إخبارنا بها"
                className={`${inputBase} ${inputColor(false)} resize-none py-4`}
              />
            </div>
          </div>

          {touched && Object.keys(errors).length > 0 && (
            <p className="mt-5 flex items-center gap-2 text-[14px] text-[#F7F6F2]/80">
              <AlertCircle size={16} strokeWidth={1.75} />
              يرجى تعبئة الحقول المطلوبة لإتمام الطلب.
            </p>
          )}

          <button
            type="button"
            onClick={submit}
            className="mt-7 w-full inline-flex items-center justify-center gap-2.5 bg-[#D62828] text-white py-5 rounded-[12px] text-[16px] sm:text-[17px] font-semibold hover:bg-[#E23838] active:scale-[0.99] transition-all min-h-[56px]"
          >
            <MessageCircle size={22} strokeWidth={1.75} />
            إرسال الطلب عبر واتساب
          </button>

          <p className="mt-5 text-center text-[12px] sm:text-[13px] text-[#A6A6A1] leading-relaxed">
            لا يتم تخزين أي بيانات — يُرسل طلبك مباشرة إلى واتساب Red Wash.
          </p>
        </Reveal>
      </div>
    </section>
  );
}