import { MessageCircle, Phone } from "lucide-react";
import Reveal from "./Reveal";
import { PHONE_TEL, openWhatsApp } from "@/lib/wazzan";

export default function FinalCTA() {
  const book = () =>
    openWhatsApp("السلام عليكم Wazzan Wash، أرغب في حجز خدمة. فضلاً أكدوا لي التوفر والسعر.");

  return (
    <section className="py-24 sm:py-36 border-t border-[#A6A6A1]/15">
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8 text-center">
        <Reveal>
          <p
            className="text-[13px] sm:text-[15px] tracking-[0.35em] text-[#A6A6A1] font-mono-num uppercase mb-6"
            style={{ direction: "ltr" }}
          >
            WAZZAN WASH
          </p>
          <h2 className="text-[30px] sm:text-[52px] md:text-[64px] font-bold tracking-tight leading-[1.15] max-w-3xl mx-auto">
            سيارتك تستاهل عناية
            <br />
            <span className="text-[#A6A6A1]">توصل لحدك.</span>
          </h2>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
            <button
              type="button"
              onClick={book}
              className="inline-flex items-center justify-center gap-2.5 bg-[#F7F6F2] text-[#050505] px-8 py-4 rounded-[12px] text-[16px] font-semibold hover:bg-white active:scale-[0.98] transition-all min-h-[52px] w-full sm:w-auto"
            >
              <MessageCircle size={20} strokeWidth={1.75} />
              احجز عبر واتساب
            </button>
            <a
              href={`tel:${PHONE_TEL}`}
              className="inline-flex items-center justify-center gap-2.5 border border-[#A6A6A1]/30 text-[#F7F6F2] px-8 py-4 rounded-[12px] text-[16px] font-semibold hover:bg-white/[0.04] transition-colors min-h-[52px] w-full sm:w-auto"
            >
              <Phone size={20} strokeWidth={1.75} />
              اتصل الآن
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}