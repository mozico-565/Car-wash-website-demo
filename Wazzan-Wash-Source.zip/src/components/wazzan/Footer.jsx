import { MessageCircle, Phone, MapPin } from "lucide-react";
import { WHATSAPP_NUMBER, PHONE_DISPLAY, PHONE_TEL, openWhatsApp } from "@/lib/wazzan";

export default function Footer() {
  const book = () =>
    openWhatsApp("السلام عليكم Wazzan Wash، أرغب في حجز خدمة. فضلاً أكدوا لي التوفر والسعر.");

  return (
    <footer className="border-t border-[#A6A6A1]/15 py-14 sm:py-16">
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-8">
          {/* Brand */}
          <div>
            <span
              className="text-[18px] font-bold tracking-[0.18em] text-[#F7F6F2]"
              style={{ direction: "ltr" }}
            >
              WAZZAN<span className="text-[#A6A6A1]"> WASH</span>
            </span>
            <p className="mt-4 text-[14px] text-[#A6A6A1] leading-relaxed max-w-xs">
              غسيل وعناية متنقلة بالسيارات في جدة، نحضر إليك أينما كنت.
            </p>
          </div>

          {/* Contact */}
          <div>
            <p className="text-[12px] tracking-[0.25em] text-[#A6A6A1] font-mono-num uppercase mb-4">
              تواصل معنا
            </p>
            <ul className="space-y-3 text-[14px]">
              <li>
                <a
                  href={`tel:${PHONE_TEL}`}
                  className="flex items-center gap-2.5 text-[#F7F6F2] hover:text-white transition-colors"
                  style={{ direction: "ltr" }}
                >
                  <Phone size={16} strokeWidth={1.75} className="text-[#A6A6A1]" />
                  {PHONE_DISPLAY}
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={book}
                  className="flex items-center gap-2.5 text-[#F7F6F2] hover:text-white transition-colors"
                >
                  <MessageCircle size={16} strokeWidth={1.75} className="text-[#A6A6A1]" />
                  واتساب
                </button>
              </li>
              <li className="flex items-center gap-2.5 text-[#A6A6A1]">
                <MapPin size={16} strokeWidth={1.75} />
                جدة، المملكة العربية السعودية
              </li>
            </ul>
          </div>

          {/* Nav */}
          <div>
            <p className="text-[12px] tracking-[0.25em] text-[#A6A6A1] font-mono-num uppercase mb-4">
              روابط
            </p>
            <ul className="space-y-3 text-[14px]">
              <li><a href="#services" className="text-[#F7F6F2] hover:text-white transition-colors">الخدمات</a></li>
              <li><a href="#how" className="text-[#F7F6F2] hover:text-white transition-colors">كيف نعمل</a></li>
              <li><a href="#gallery" className="text-[#F7F6F2] hover:text-white transition-colors">الأعمال</a></li>
              <li><a href="#booking" className="text-[#F7F6F2] hover:text-white transition-colors">الحجز</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-[#A6A6A1]/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[12px] text-[#A6A6A1]/70" style={{ direction: "ltr" }}>
            © {new Date().getFullYear()} WAZZAN WASH. ALL RIGHTS RESERVED.
          </p>
          <p className="text-[12px] text-[#A6A6A1]/70">صُمم لجدة.</p>
        </div>
      </div>
    </footer>
  );
}