import Reveal from "./Reveal";
import { SERVICES } from "@/lib/wazzan";

export default function Services() {
  return (
    <section id="services" className="py-20 sm:py-32">
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 border-b border-[#A6A6A1]/15 pb-8 mb-2">
            <div>
              <p className="text-[12px] tracking-[0.3em] text-[#A6A6A1] font-mono-num uppercase mb-3">
                01 — Services
              </p>
              <h2 className="text-[30px] sm:text-[44px] font-bold tracking-tight">الخدمات</h2>
            </div>
            <p className="text-[13px] sm:text-[14px] text-[#A6A6A1] max-w-xs leading-relaxed">
              الخدمات والأسعار النهائية يتم تأكيدها عند الحجز.
            </p>
          </div>
        </Reveal>

        <div className="divide-y divide-[#A6A6A1]/15">
          {SERVICES.map((s, i) => (
            <Reveal key={s.id} delay={i * 0.08}>
              <div className="group py-7 sm:py-9 flex items-center gap-5 sm:gap-10 transition-colors duration-300 hover:bg-white/[0.02] sm:hover:px-6 sm:-mx-6 sm:rounded-[12px]">
                <span className="font-mono-num text-[13px] sm:text-[15px] text-[#A6A6A1] w-8 shrink-0">
                  {s.id}
                </span>
                <div className="flex-1 min-w-0">
                  <h3 className="text-[22px] sm:text-[30px] font-semibold tracking-tight text-[#F7F6F2] mb-1.5">
                    {s.name}
                  </h3>
                  <p className="text-[14px] sm:text-[16px] text-[#A6A6A1] leading-relaxed">
                    {s.desc}
                  </p>
                </div>
                <span className="hidden sm:block text-[#A6A6A1] text-[12px] tracking-[0.25em] font-mono-num opacity-0 group-hover:opacity-100 transition-opacity">
                  احجز ←
                </span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}