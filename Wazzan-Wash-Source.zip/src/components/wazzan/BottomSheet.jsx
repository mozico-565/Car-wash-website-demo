import { motion, AnimatePresence } from "framer-motion";
import { X, Check } from "lucide-react";

// Custom mobile bottom sheet — warm-white, black text, spring slide,
// drag handle, close button, large touch targets, custom check indicator.
// Never uses native HTML selects.
export default function BottomSheet({
  isOpen,
  onClose,
  title,
  options,
  selectedValue,
  onSelect,
}) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-[2px]"
            aria-hidden="true"
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={title}
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 320 }}
            className="fixed bottom-0 inset-x-0 z-[100] bg-[#F7F6F2] text-[#050505] rounded-t-[20px] pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-3 px-5 shadow-[0_-12px_40px_rgba(0,0,0,0.4)]"
          >
            <div className="w-10 h-1.5 bg-black/15 rounded-full mx-auto mb-5" />
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-lg font-semibold tracking-tight">{title}</h3>
              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق"
                className="w-11 h-11 -me-2 flex items-center justify-center text-black/60 hover:text-black transition-colors"
              >
                <X size={22} strokeWidth={1.75} />
              </button>
            </div>
            <div className="max-h-[60vh] overflow-y-auto no-scrollbar">
              <ul className="space-y-1.5 pb-2">
                {options.map((opt) => {
                  const active = selectedValue === opt;
                  return (
                    <li key={opt}>
                      <button
                        type="button"
                        onClick={() => {
                          onSelect(opt);
                          onClose();
                        }}
                        className={`w-full min-h-[56px] px-5 rounded-[12px] flex items-center justify-between transition-colors ${
                          active ? "bg-[#050505] text-[#F7F6F2]" : "bg-black/[0.04] hover:bg-black/[0.08] text-[#050505]"
                        }`}
                      >
                        <span className="text-[17px] font-medium">{opt}</span>
                        {active && <Check size={20} strokeWidth={2} />}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}