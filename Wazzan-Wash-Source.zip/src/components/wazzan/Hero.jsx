import { motion } from "framer-motion";
import { MessageCircle, Phone } from "lucide-react";
import { Image } from "@/components/ui/image";
import { IMAGES, PHONE_TEL, openWhatsApp } from "@/lib/wazzan";

export default function Hero() {
  const book = () =>
    openWhatsApp("السلام عليكم Wazzan Wash، أرغب في حجز خدمة. فضلاً أكدوا لي التوفر والسعر.");

  return (
    <section id="top" className="relative min-h-[100svh] flex items-end overflow-hidden">
      {/* Photographic background */}
      <div className="absolute inset-0 z-0">
        <Image
          src={IMAGES.hero}
          alt="عناية فاخرة بسيارة — تفاصيل الإضاءة وقطرات الماء"
          fittingType="fill"
          className="w-full h-full object-cover"
        />
        {/* Tonal overlays — no colorful gradients */}
        <div className="absolute inset-0 bg-[#050505]/55" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/30 to-[#050505]/40" />
      </div>

      <div className="relative z-10 w-full mx-auto max-w-[1280px] px-5 sm:px-8 pb-16 pt-28 sm:pb-24">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-[640px]"
        >
          <p className="text-[12px] sm:text-[13px] tracking-[0.3em] text-[#A6A6A1] mb-5 font-mono-num uppercase">
            JEDDAH · MOBILE DETAILING
          </p>
          <h1 className="text-[34px] leading-[1.15] sm:text-[58px] md:text-[72px] font-bold tracking-tight text-[#F7F6F2]">
            العناية بسيارتك،
            <br />
            <span className="text-[#A6A6A1]">توصلك إلى موقعك.</span>
          </h1>
          <p className="mt-6 text-[16px] sm:text-[20px] leading-[1.7] text-[#A6A6A1] max-w-[30rem]">
            غسيل وعناية متنقلة بالسيارات في جدة، نحضر إليك أينما كنت.
          </p>

          <div className="mt-9 flex flex-col sm:flex-row gap-3 sm:gap-4">
            <button
              type="button"
              onClick={book}
              className="inline-flex items-center justify-center gap-2.5 bg-[#F7F6F2] text-[#050505] px-7 py-4 rounded-[12px] text-[15px] sm:text-[16px] font-semibold hover:bg-white active:scale-[0.98] transition-all min-h-[52px]"
            >
              <MessageCircle size={20} strokeWidth={1.75} />
              احجز عبر واتساب
            </button>
            <a
              href={`tel:${PHONE_TEL}`}
              className="inline-flex items-center justify-center gap-2.5 border border-[#A6A6A1]/30 text-[#F7F6F2] px-7 py-4 rounded-[12px] text-[15px] sm:text-[16px] font-semibold hover:bg-white/[0.04] transition-colors min-h-[52px]"
            >
              <Phone size={20} strokeWidth={1.75} />
              اتصل الآن
            </a>
          </div>
        </motion.div>
      </div>

      {/* thin bottom separator */}
      <div className="absolute bottom-0 inset-x-0 h-px bg-[#A6A6A1]/15 z-10" />
    </section>
  );
}