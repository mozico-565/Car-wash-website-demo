import { MapPin, MessageCircle } from "lucide-react";
import Reveal from "./Reveal";
import { openWhatsApp } from "@/lib/redwash";

export default function Coverage() {
  const sendLocation = () =>
    openWhatsApp("السلام عليكم Red Wash، أرغب في الاستفسار عن الخدمة والتوفر.");

  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-[1280px] px-5 sm:px-8">
        <Reveal>
          <div className="border border-[#A6A6A1]/15 rounded-[14px] p-8 sm:p-14 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-8">
            <div className="flex items-start gap-5">
              <div className="w-12 h-12 rounded-[12px] border border-[#A6A6A1]/25 flex items-center justify-center shrink-0">
                <MapPin size={22} strokeWidth={1.5} className="text-[#A6A6A1]" />
              </div>
              <div>
                <h2 className="text-[24px] sm:text-[32px] font-semibold tracking-tight mb-2">
                  Red Wash في جدة
                </h2>
                <p className="text-[15px] sm:text-[16px] text-[#A6A6A1] max-w-md leading-relaxed">
                  أرسل تفاصيل سيارتك والخدمة المطلوبة عبر واتساب للتأكد من التوفر.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={sendLocation}
              className="inline-flex items-center justify-center gap-2.5 bg-[#D62828] text-white px-7 py-4 rounded-[12px] text-[15px] font-semibold hover:bg-[#E23838] active:scale-[0.98] transition-all min-h-[52px] shrink-0"
            >
              <MessageCircle size={20} strokeWidth={1.75} />
              تواصل عبر واتساب
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}