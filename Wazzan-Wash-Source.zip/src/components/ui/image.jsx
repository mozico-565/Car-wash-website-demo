import * as React from "react";

// Minimal local Image component (no Base44/Wix media dependency).
// Mirrors the API used by the components: { src, fittingType, className, alt, ... }.
// `fittingType` is accepted for API compatibility but ignored — sizing is
// controlled via className (e.g. "w-full h-full object-cover").
export const Image = React.forwardRef(function Image(
  { src, fittingType, ...props },
  ref
) {
  return (
    <img
      ref={ref}
      src={src}
      loading="lazy"
      decoding="async"
      {...props}
    />
  );
});