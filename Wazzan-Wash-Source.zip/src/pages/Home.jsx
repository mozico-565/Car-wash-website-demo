import Header from "@/components/wazzan/Header";
import Hero from "@/components/wazzan/Hero";
import Services from "@/components/wazzan/Services";
import HowItWorks from "@/components/wazzan/HowItWorks";
import Gallery from "@/components/wazzan/Gallery";
import Booking from "@/components/wazzan/Booking";
import Coverage from "@/components/wazzan/Coverage";
import FAQ from "@/components/wazzan/FAQ";
import FinalCTA from "@/components/wazzan/FinalCTA";
import Footer from "@/components/wazzan/Footer";

export default function Home() {
  return (
    <div className="bg-[#050505] text-[#F7F6F2] min-h-screen">
      <Header />
      <main>
        <Hero />
        <Services />
        <HowItWorks />
        <Gallery />
        <Booking />
        <Coverage />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}