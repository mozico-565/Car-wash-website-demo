import Home from "@/pages/Home";

// Single-page site. No router is needed: navigation uses native in-page
// anchors (#services, #booking, ...), which work on GitHub Pages without
// server rewrites (the hash is never sent to the server, so no 404 on refresh).
export default function App() {
  return <Home />;
}